// ==UserScript==
// @name         fenduoduo
// @version      0.2.11.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       ZhangZisu <admin@zhangzisu.cn>
// @license      MIT
//
// @include      http*://ks.wjx.top/*
//
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
//
// @connect      v4.ipv6-test.com
// @connect      ip-api.com
// @connect      fdd.19260817.net
// @namespace https://greasyfork.org/users/232165
// ==/UserScript==
