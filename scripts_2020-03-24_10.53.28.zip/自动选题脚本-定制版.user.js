// ==UserScript==
// @name         自动选题脚本-定制版
// @namespace    www.tuziang.com
// @version      0.2
// @description  一个自动选题脚本
// @author       Tuziang
// @match        *://*.wjx.top/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var length = document.getElementsByClassName("ui-controlgroup").length
    for (var i = 0; i < length; i++) {
        document.getElementsByClassName("ui-controlgroup")[i].getElementsByClassName("label")[0].click()
    }
    $("input").off("paste");
})();