
/*
 * @Author: https://www.xuehuayu.cn
 * @Date:2019-08-12 19:52:21 
 * @Last Modified by: np
 * @Last Modified time: 2020-03-02 01:45:05
 */

// ==UserScript==
// @name         CaiNiaoScript[author：xuehuayu.cn]
// @name:zh      多功能脚本[作者：xuehuayu.cn]
// @author       https://www.xuehuayu.cn
// @homepage     https://www.xuehuayu.cn
// @namespace    https://www.xuehuayu.cn/?from=cainiaojiaoben
// @version      2020-03-01 02:33:05
// @description  [无优惠券无推广！不可能满足所有人，不好用不用就是，拒绝BB。] PC端手机端通用，完全免费无推广，我写脚本也没用到服务器，所以没优惠券推广也没脸说补贴服务器要打赏。：1、顽固广告清除，保护隐私；2、视频直接看，音乐直接下载；3、购物历史价格；5、[手机]热门网站内容，自动展开去烦人的app下载和推荐；6、百度文库直接下载；7、太长了，懒得写了，其他功能自己探索
// @include      *ayxvip.com*
// @include      *.//music.163.com/*
// @include      *//*.mgtv.com/b/*
// @include      *//3g.163.com/*
// @include      *//jingyan.baidu.com/*
// @include      *iyouman.com/*
// @include      *://zhidao.baidu.com/*
// @include      *://m.sohu.com/*
// @include      *://www.zhihu.com/*
// @include      *://xw.qq.com/*
// @include      *://tieba.baidu.com/f*
// @include      *://sina.cn/*
// @include      *://blog.csdn.net*
// @include      *://m.youku.com/*
// @include      *://v.youku.com/*
// @include      *://www.baidu.com/sf_baijiahao/*
// @include      *://baijiahao.baidu.com*
// @include      *://m.toutiao.com*
// @include      *://m.uczzd.cn*
// @include      *://mparticle.uc.cn/article*
// @include      *://m.baidu.com/*
// @include      *://www.baidu.com/*
// @include      *://wenku.baidu.com/view/*
// @include      *://wk.baidu.com/view/*
// @include      *://item.taobao.com/item.htm*
// @include      *://detail.tmall.com/item.htm*
// @include      *://h5.m.taobao.com/awp/core/detail.htm*
// @include      *://item.jd.*
// @include      *://item.m.jd.*
// @include      *://mitem.jd.*
// @include      *://*goods.kaola.com/product*
// @include      *://product.suning.*
// @include      *://m.suning.com/product*
// @include      *://product.dangdang.*
// @include      *://product.m.dangdang.*
// @include      *://v.qq.com/x/cover*
// @include      *://m.v.qq.com/play*
// @include      *://m.v.qq.com/cover*
// @include      *://*.iqiyi.com/v_*
// @include      *://y.qq.com/n/yqq/song/*
// @include      *://www.xuehuayu.cn*
// @require      https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js
// @run-at       document-end
// ==/UserScript==

$(function () {
  console.log('欢迎使用 [ xuehuayu.cn ] 提供的脚本')

  setTimeout(function () {
    var t = location.href // location.href
    var l = void 0 // location
    var w = void 0 // button text
    var bw = 'auto' // button width
    var bh = '44px' // button height
    var left = 0
    var bottom = 0
    var fz = '18px' // button font-size
    var priceWrap = void 0
    var timerL = null
    var timerB = null
    var timerG = null
    var flag = true
    var msec = 5e2

    setInterval(() => {
      t = location.href
    }, 2e3);

    startScript()

    window.ontouchstart = function () {
      flag = true
      clearTimer(timerG)
      timerG = setInterval(() => {startExtend()}, 5e2)
    }

    window.addEventListener('popstate', function () {
      setTimeout(() => {startScript()}, 5e2)
    })

    function startScript () {
      filerCrypt()
      startExtend()
      getObsEle()
      JXV()
      addTools()
    }

    function startExtend () {
      clearIYM()
      autoExtendWYXW()
      autoExtendJingYan()
      autoExtendZhiDao()
      autoExtendSoHu()
      autoExtendZH()
      autoExtendTXXW()
      autoExtendTieBa()
      autoExtendCSDN()
      autoExtendBJH()
      autoExtendTT()
      autoExtendUC()
    }

    // 屏蔽拿着免费的东西去收费的垃圾
    function filerCrypt () {
      if (t) clearTimer(timerL)
      filterUrlList.forEach(e => {
        if (t.indexOf(e) > -1) {
          window.location.href = 'https://www.xuehuayu.cn/2019/09/26/AdGuard%E8%A7%84%E5%88%99/'
        }
      })
    }

    function clearIYM () {
      if (t) clearTimer(timerL)
      var timerIYM = null
      if (t.indexOf('iyouman.com/') > -1) {
        (function(){
          var style = document.createElement('style')
          style.type = 'text/css'
          style.innerText = 'img::after{display: none !important;} .rd-main .comic-page.lock .comic-img:after {content: ""; display: none !important;}'
          document.head.append(style)
        })();
        timerIYM = setInterval(function(){
          $('img.comic-pic').css('filter', 'none')
          $('img:after').hide()
          $('#js_payChapter').remove && $('#js_payChapter').remove()
          $('.pay-chapter-modal').remove && $('.pay-chapter-modal').remove()
        }, 1e3)
      } else {
        clearTimer(timerIYM)
      }
    }

    function autoExtendWYXW () {
      if (t) clearTimer(timerL)
      if (flag && t.match(/3g.163.com\/\w+\/article/)) {
        console.log('wyxw')
        $('.doc-footer-wrapper').remove() && $('.doc-footer-wrapper').remove()
        $('.wakeup_client').remove() && $('.wakeup_client').remove()
        $('.footer').remove() && $('.footer').remove()
        $('article').css('max-height', 'none')
      }
    }

    function autoExtendJingYan () {
      if (t) clearTimer(timerL)
      if (flag && t.indexOf('jingyan.baidu.com/article/') > -1) {
        console.log('jingyan')
        $('.exp-content-container').removeClass('fold')
        $('.read-whole-mask').remove && $('.read-whole-mask').remove()

        !$('.exp-content-container').hasClass('fold') && $('.read-whole-mask')[0] && (flag = false) 
      }
    }

    function autoExtendZhiDao () {
      if (t) clearTimer(timerL)
      if (flag && t.indexOf('zhidao.baidu.com/question/') > -1) {
        console.log('zhidao')
        $('.w-detail-display-btn').hide()
        $('.icon-bdad').remove()
        $('.w-detail-full').removeClass('w-detail-isfold')
        $('#w-2').removeClass('w-detail-isfold')
        $('.w-detail-container').css('max-height', 'initial')
        !$('.icon-bdad')[0] && !$('#w-2').hasClass('w-detail-isfold') && !$('.w-detail-full').hasClass('w-detail-isfold') && (flag = false) 
      }
    }

    function autoExtendSoHu () {
      if (t) clearTimer(timerL)
      if (flag && t.indexOf('m.sohu.com/a/') > -1) {
        console.log('sohu news')
        $('.lookall-box').hide()
        $('.hidden-content').removeClass('hide')
        !$('.hidden-content').hasClass('hide') && (flag = false)
      }
    }

    function autoExtendZH () {
      if (t) clearTimer(timerL)
      setTimeout(function() {flag = false}, 3000)
      if (flag && t.indexOf('zhihu.com/question') > -1) {
        flag = false
        $('.RichContent').removeClass('is-collapsed RichContent--unescapable').addClass('RichContent--unescapable')
        $('.RichContent-inner').css('max-height', 'none')
        $('.RichContent').find('button').hide()
        $('.HotQuestions').hide()
        $('body').css('overflow', 'auto')
        $('img').on('click', function(event) {
          $('body').css('overflow', 'auto')
          event.stopPropagation ? event.stopPropagation() : event.cancelBubble
        })
        $('.RichContent').on('click', function(event) {
          $('body').css('overflow', 'auto')
          event.stopPropagation ? event.stopPropagation() : event.cancelBubble
        })
        $('.RichContent-inner').on('click', function(event) {
          $('body').css('overflow', 'auto')
          event.stopPropagation ? event.stopPropagation() : event.cancelBubble
        })
        $('.RichText').on('click', function(event) {
          $('body').css('overflow', 'auto')
          event.stopPropagation ? event.stopPropagation() : event.cancelBubble
        })
      }
    }

    function autoExtendTXXW () {
      if (t) clearTimer(timerL)
      if (flag && t.match(/xw.qq.com\/\w{2,}\//)) {
        console.log('txxw')
        $('#article_body').removeClass('packed').addClass('unpack')
        $('.container').hide()
        $('.ct-title').hide()
        $('.mask').remove && $('.mask').remove()
        $('.collapseWrapper').remove && $('.collapseWrapper').remove()
        $('.item-list').remove && $('.item-list').remove()
        $('#article_body').hasClass('unpack') && (flag = false)
      } else if (t.match(/xw.qq.com\/\w\//)) {
        flag = true
        $('.container').show()
        $('.ct-title').show()
      }
    }

    function autoExtendTieBa () {
      if (t) clearTimer(timerL)
      setTimeout(function() {flag = false}, 3000)
      if (flag && t.indexOf('tieba.baidu.com/f') > -1) {
        $('.show_more')[0] && ($('.show_more')[0].click(), $('.show_more').remove(),flag = false) 
      }
    }

    function autoExtendCSDN () {
      if (t) clearTimer(timerL)
      setTimeout(function() {flag = false}, 3000)
      if (flag && t.match(/.*blog.csdn.net\/.*\/article\/details.*/)) {
        $('.hide-article-box').remove && $('.hide-article-box').remove()
        $('#article_content').removeAttr('style')
        $('.btn-readmore')[0] && ($('.btn-readmore')[0].click(), $('.btn-readmore').remove(),flag = false) 
        $('#new_read_more')[0] && ($('#new_read_more')[0].click(), $('#new_read_more').remove(), flag = false)
      }
    }

    function autoExtendBJH () {
      if (t) clearTimer(timerL)
      if (t.indexOf('baijiahao.baidu.com/s') > -1 || t.indexOf('baidu.com/sf_baijiahao') > -1) {
        var timerBJH = setInterval(() => {
          var ctnWrap = $('.mainContent')
          var extBtn = $('.packupButton')
          if (ctnWrap[0]) {
            console.log('BJH')
            ctnWrap.css('height', '100%')
            extBtn.remove && extBtn.remove()
            $('.outmargin').remove && $('.outmargin').remove()
            clearTimer(timerBJH)
          }
        }, msec)
      }
    }

    function autoExtendTT() {
      if (t) clearTimer(timerL)
      if (t.indexOf('m.toutiao.com/') > -1) {
        var timerTT = setInterval(function () {
          console.log('timerTT')
          var unfold = $('.unfold-field-download')
          if (!unfold[0] || unfold.css('display') === 'none') clearTimer(timerTT)
          $('.article').children().eq(0).css('height', 'auto')
          unfold.remove && unfold.remove()
        }, msec)
      }
    }
    
    function autoExtendUC() {
      if (t) clearTimer(timerL)
      if (t.indexOf('mparticle.uc.cn/article') > -1) {
        var timerUC = setInterval(function () {
          console.log('timerUC')
          var showMoreBtn = $('.show-more')
          if (!showMoreBtn[0] || showMoreBtn.css('display') === 'none') clearTimer(timerUC)
          var moreContent = $('.content-cover')
          var Footer = $('.Footer')
          var shareTmportTitle = $('.share-import-title')
          var iframes = $('iframe')
          var recommend = $('.Recommend')
          if (showMoreBtn && moreContent) {
            moreContent.css({
              'max-height':'none',
              'overflow':'visible'
            })
            showMoreBtn.remove && showMoreBtn.remove()
            Footer.remove && Footer.remove()
            shareTmportTitle.remove && shareTmportTitle.remove()
            recommend.remove && recommend.remove()
            iframes.remove && iframes.remove()
          }
        }, msec)
      }
      if (t.indexOf('uczzd.cn/webview/news') > -1) {
        var timerUC = setInterval(function () {
          var showMoreBtn = $('.show-all')
          if (!showMoreBtn[0] || showMoreBtn.css('display') === 'none') clearTimer(timerUC)
          var moreContent = $('#contentShow')
          var Footer = $('.Footer')
          var shareTmportTitle = $('.share-import-title')
          var iframes = $('iframe')
          var recommend = $('.Recommend')
          var showMoreDetail = $('.show-more-detail')
          if (showMoreBtn && moreContent) {
            moreContent.css({
              'max-height':'none',
              'overflow':'visible'
            })
            showMoreBtn.remove && showMoreBtn.remove()
            Footer.remove && Footer.remove()
            shareTmportTitle.remove && shareTmportTitle.remove()
            recommend.remove && recommend.remove()
            showMoreDetail.remove && showMoreDetail.remove()
            iframes.remove && iframes.remove()
          }
        }, msec)
      }
    }

    function getObsEle() {
      if (t) clearTimer(timerL)
      if (t.indexOf('//m.baidu.com') > -1 || (t.indexOf('//www.baidu.com') > -1 && t.indexOf('baijiahao') === -1)) {
        getObsEleFn()
        function getObsEleFn() {
          fixedArr = []
          var divs = $('div')
          $('.index-banner').remove && $('.index-banner').remove()
          divs.each(function (idx, ele) {
            var elePosStyle = $(ele).css('position')
            var eleBotStyle = $(ele).css('bottom')
            var eleClassName = $(ele).attr('class')
            var eleStyle = $(ele).attr('style')
            if (
              (elePosStyle === 'fixed' && eleBotStyle === '0px') ||
              eleClassName === 'ads-item' ||
              (eleStyle && (eleStyle.indexOf('block!important') > -1 || eleStyle.indexOf('visible!important') > -1))
            ) {
              fixedArr.push(elePosStyle || eleBotStyle || eleDisStyle)
              isPhone() && ele.remove && ele.remove()
            }
          })
        }
        if (fixedArr.length > 0) {
          clearTimer(timerB)
          timerB = setInterval(() => {
            console.log('timerB', fixedArr)
            if (fixedArr.length === 0) {
              clearTimer(timerB)
            } else {
              getObsEleFn()
            }
          }, msec)
        }
      }
    }

    function addTools() {
      if (t) clearTimer(timerL)
      else return
      if (t.indexOf('//wenku.baidu.com/view') > -1) {
        l = 'bdwk'
        w = '免费下载'
        bw = 'auto'
        bh = '44px'
        t = t.replace(/\.baidu\./, ".baiduvvv.")
      }
      if (t.indexOf('//wk.baidu.com/view') > -1) {
        l = 'bdwkm'
        w = '免费下载'
        bw = 'auto'
        bh = '44px'
        t = t.replace(/wk\.baidu\./, "wenku.baiduvvv.")
      } else if (t.indexOf('//detail.tmall.') > -1) {
        l = 'tm'
        w = '历史价格'
        left = '10px'
        t = t.replace(/\.tmall\./, '.tmallvvv.')
      } else if (t.indexOf('//item.taobao') > -1) {
        l = 'tb'
        w = '历史价格'
        left = '10px'
        t = t.replace(/\.taobao\./, '.taobaovvv.')
      } else if (t.indexOf('//m.taobao.com/awp/core/detail') > -1) {
        l = 'tbm'
        w = '历史价格'
        bh = '36px'
        fz = '14px'
        t = t.replace(/\.taobao\./, '.taobaovvv.')
      } else if (t.indexOf('//item.jd') > -1) {
        l = 'jd'
        w = '历史价格'
        t = t.replace(/\.jd\.\w{1,3}/, '.jdvvv.com')
      } else if (t.indexOf('//mitem.jd') > -1 || t.indexOf('//item.m.jd') > -1) {
        l = 'jdm'
        w = '历史价格'
        t = t.replace(/\.jd\.\w{1,3}/, '.jdvvv.com')
      } else if (t.indexOf('goods.kaola') > -1) {
        l = 'kl'
        w = '历史价格'
        left = '10px'
        t = t.replace(/(m-)?goods\.kaola\./, 'goods.kaolavvv.')
      } else if (t.indexOf('//product.suning') > -1) {
        l = 'sn'
        w = '历史价格'
        left = '10px'
        bottom = '10px'
        t = t.replace(/\.suning\./, '.suningvvv.')
      } else if (t.indexOf('//m.suning.com/product') > -1) {
        l = 'snm'
        w = '历史价格'
        t = t.replace('m.suning.com/product', 'product.suningvvv.com')
      } else if (t.indexOf('//product.dangdang') > -1) {
        l = 'dd'
        w = '历史价格'
        left = '100px'
        bottom = '36px'
        t = t.replace(/\.dangdang\./, '.dangdangvvv.')
      } else if (t.indexOf('//product.m.dangdang') > -1) {
        l = 'ddm'
        w = '历史价格'
        left = '10px'
        var protocol = location.href.split(':')[0]
        var pid = location.search.match(/\d{4,}/)[0]
        t = `${protocol}://product.dangdangvvv.com/${pid}.html`
      } else if (t.indexOf('item.gome') > -1) {
        l = 'gm'
        w = '历史价格'
        t = t.replace(/\.gome\./, '.gomevvv.')
      }
    }
    var aEle = document.createElement("a")
    aEle.href = t
    aEle.innerText = w
    aEle.setAttribute('target', '_blank')
    aEle.style.cssText = `position:relative;z-index:11;display:inline-block;box-sizing:border-box;left:${left};bottom:${bottom};width:${bw};height:${bh};border:5px solid #00f;padding:5px;background-color:#f00;color:#fff;font-size:${fz}`;
    var cb = aEle.cloneNode(true)
    var cb2 = aEle.cloneNode(true)
    var cb3 = aEle.cloneNode(true)
    switch (l) {
      case 'bdwk':
        var hdb = $('#doc-header-test')
        var tdb = $('.top-down-load-container')
        var bdb = $('.toolbar-core-btns-wrap')
        var dbb = $('.doc-bottom-btns')
        cb2.style.height = '52px'
        hdb.append(aEle)
        tdb.html(cb).css({
          'box-sizing':'border-box',
          'top':0,
          'line-height':'22px'
        })
        bdb.html(cb2).css({
          'line-height':'30px'
        })
        dbb.html(cb3)
        break
      case 'bdwkm':
        $('.btn-view-in-app').remove && $('.btn-view-in-app').remove()
        var btnWrap = $('.top-doc-info-root')
        var bdb = $('.down-area-wp')
        btnWrap.append(aEle)
        cb.innerText = '下载'
        cb.style.cssText = `${cb2.style.cssText}line-height:22px;`
        bdb.html(cb)
        break
      case 'tm':
        priceWrap = $('.tm-price-panel dd').eq(0)
        priceWrap.append(aEle)
        break
      case 'tb':
        priceWrap = $('.tb-promo-item-bd') || $('#J_Title')
        priceWrap.append(aEle)
        break
      case 'tbm':
        priceWrap = $('.main-price-wrapper') || $('.d-price')
        priceWrap.append(aEle)
        break
      case 'jd':
        priceWrap = $('.summary-price .dd').eq(0)
        priceWrap.append(aEle)
        break
      case 'jdm':
        var priceWrap1 = $('#priceSale')
        var priceWrap2 = $('#priceSpec')
        priceWrap1.append(aEle)
        priceWrap2.append(cb)
        break
      case 'kl':
        var priceWrap1 = $('.m-price-cnt')
        var priceWrap2 = $('.n-price__left')
        cb.style.cssText = `${cb.style.cssText}line-height:22px`
        priceWrap1.append(aEle)
        priceWrap2.append(cb)
        break
      case 'sn':
        priceWrap = $('.price-promo dd').eq(0)
        priceWrap.append(aEle)
        break
      case 'snm':
        priceWrap = $('#pricemain')
        var priceWrap2 = $('#jumain')
        priceWrap.append(aEle)
        priceWrap2.append(cb)
        break
      case 'dd':
        priceWrap = $('#pc-price')
        priceWrap.append(aEle)
        break
      case 'ddm':
        priceWrap = $('.original_price')
        priceWrap.append(aEle)
        break
      default:
        break
    }

    function JXV() {
      if (t) clearTimer(timerL)
      else return
      var location = window.location
      var origin = location.origin
      var pathname = location.pathname
      var url = origin + pathname
      var mselect = document.createElement('select')
      var vselect = document.createElement('select')
      vselect.innerHTML = `<option value='default'>免VIP看</option>`
      vselect.title = '不能看请多刷新几次，还是不行，就换一个'
      vselect.setAttribute('value', 'default')
      mselect.innerHTML = `<option value='default'>免VIP下</option>`
      mselect.style.cssText = vselect.style.cssText = 'background-color:yellow;color:#000;margin-left:10px;width:80px;height:35px;font-size:12px;'
      mselect.setAttribute('value', 'default')
      for (var n in JXVEDIO) {
        var option = document.createElement('option')
        option.setAttribute('value', JXVEDIO[n])
        option.innerText = n
        vselect.appendChild(option)
      }
      vselect.setAttribute('onchange', 'this.value!=="default"&&window.open(this.value + window.location.origin + window.location.pathname, "_target")')

      JXMUSIC.forEach((e, i) => {
        var option = document.createElement('option')
        option.setAttribute('value', e)
        option.innerText = `接口 ${i + 1}`
        mselect.appendChild(option)
      })
      mselect.addEventListener('change', function () {
        console.log('m onchange')
        if (this.value === 'default') return
        window.open(this.value + (url || t), '_target')
      })
      vselect.addEventListener('change', function () {
        console.log('v onchange')
        if (this.value === 'default') return
        window.open(this.value + (url || t), '_target')
      })
      if (t.indexOf('m.v.qq.com/play') > -1) {
        var vid = GetQueryString('vid')
        var cid = GetQueryString('cid')
        url = 'https://v.qq.com/x/cover/' + cid +'/'+ vid + '.html'
        $('.video_tit').append(vselect)
      } else if (t.indexOf('m.v.qq.com/cover') > -1) {
        var vid = GetQueryString('vid')
        var cid = GetQueryString('cid')
        if (!cid) {
          var dotIndex = t.lastIndexOf('.html')
          var lineIndex = t.lastIndexOf('/') + 1
          cid = t.substring(lineIndex, dotIndex)
        }
        url = 'https://v.qq.com/x/cover/' + cid +'/'+ vid + '.html'
        $('.video_tit').append(vselect)
      } else if (t.indexOf('v.qq.com/x/cover') > -1) {
        $('.tvip_layer').remove && $('.tvip_layer').remove()
        $('.site_channel').append(vselect)
        $('.player_title').append(vselect.cloneNode(true))
        $('.video_base _base').append(vselect.cloneNode(true))
        $('.vertical_center_box').html(vselect.cloneNode(true))
      } else if (t.indexOf('y.qq.com/n/yqq') > -1) {
        mselect.style.cssText = mselect.style.cssText + 'vertical-align:top;'
        mselect.setAttribute('title', '')
        url = '?type=qq&name='+$('.data__name_txt').text()
        $('.data__actions').append(mselect)
      } else if (t.indexOf('y.qq.com/n/yqq') > -1) {
        mselect.style.cssText = mselect.style.cssText + 'vertical-align:top;'
        mselect.setAttribute('title', '')
        url = '?type=qq&name='+$('.data__name_txt').text()
        $('.data__actions').append(mselect)
      } else if (t.match(/music.163.com.*\?id=*/)) {
        console.error('adguard脚本无法注入到iframe页面中')
      } else if (t.indexOf('www.iqiyi.com/v_') > -1) {
        $('div[is="i71-playpage-sdrama-floater"]').attr(':initialized-data')
        var Q = ''
        var token = ''
        vselect.className = 'qy-novip'
        $('.search-box').eq(0).css({'display': 'inline-block', 'vertical-align': 'top' })
        $('.search-box').eq(0).after(vselect.cloneNode(true))
        $('.qy-player-side-vip') ? $('.qy-player-side-vip').eq(0).html(vselect) : $('.player-title').eq(0).html(vselect)
        
        var timerqy = null
        timerqy = setInterval(function(){
          if (!$('.qy-player-side-vip').find('select')[0]) {
            $('.qy-player-side-vip') ? $('.qy-player-side-vip').eq(0).html(vselect) : $('.player-title').eq(0).html(vselect)
          }
          if (!$('.qy-search').find('select')[0]) {
            $('.search-box').eq(0).css({'display': 'inline-block', 'vertical-align': 'top' })
            $('.search-box').eq(0).after(vselect.cloneNode(true))
          }
        }, 2e3)
        setTimeout(function () {
          clearInterval(timerqy)
        }, 2e4)
      } else if (t.indexOf('m.iqiyi.com/v_') > -1) {
        var Q = ''
        var token = ''
        vselect.className = 'qy-novip'
        $('.m-iqylink-guide') ? $('.m-iqylink-guide').eq(0).html(vselect) : $('.m-title').eq(0).html(vselect)
        setTimeout(function(){
          $('.m-iqylink-guide') ? $('.m-iqylink-guide').eq(0).html(vselect) : $('.m-title').eq(0).html(vselect)
        }, 1e3)
      } else if (t.indexOf('v.youku.com/v_show/id_') > -1) {
        vselect.className = 'yk-novip'
        $('#bpmodule-playpage-righttitle')[0] && $('#bpmodule-playpage-righttitle').append(vselect)
        $('#youku-search-box')[0] && $('#youku-search-box').css('display', 'inline-block').after(vselect.cloneNode(true))
        var yktimer = null
        yktimer = setInterval(function () {
          if (!$('#vip_limit_content_sid')[0]) {
            $('#vip_limit_content_sid').html('').append(vselect.cloneNode(true))
          } else {
            $('#vip_limit_content_sid').html('').append(vselect.cloneNode(true))
            clearInterval(yktimer)
            yktimer = null
          }
        }, 2e3)
        setTimeout(function () {
          clearInterval(yktimer)
          yktimer = null
        }, 1e4)
      } else if (t.indexOf('m.youku.com/video/id_') > -1 || t.indexOf('m.youku.com/alipay_video/id_') > -1) {
        $('.brief-title').append(vselect)
      } else if (t.match(/.*\/\/www.mgtv.com\/b\/\d+\/\d+.html.*/)) {
        $('.c-header-search-form')[0] && $('.c-header-search-form').css('display', 'inline-block').after(vselect.cloneNode(true))
        $('.v-panel-title').append(vselect.cloneNode(true))
      } else if (t.match(/.*\/\/m.mgtv.com\/b\/\d+\/\d+.html.*/)) {
        console.info('mgtv m')
        $('h1.vtit').append(vselect)
      }

    } //
  }, 1e3)

  var JXVEDIO = {
    '问题反馈(非解析)':'https://www.xuehuayu.cn/2019/09/26/AdGuard%E8%A7%84%E5%88%99/#comments?url=',
    '菜鸟解析':'https://jiexi.bm6ig.cn/?url=',
    '598解析':'http://jx.598110.com/?url=',
    '酷酷云':'https://www.jiexila.com/?url=',
    '8k解析':'https://jx.8kjx.com/?url=',
    '41解析':'https://jx.f41.cc/?url=',
    '黑云1':'http://dhyjiexi.arpps.com/?url=',
    '黑云2':'http://jiexi.380k.com/?url=',
    '二度解析1':'http://jx.du2.cc/?url=',
    '二度解析2':'http://jx.drgxj.com/?url=',
    '二度解析3':'http://jx.drgxj.com/v/10.php?url=',
    '通用1':'http://jx.598110.com/?url=',
    '通用2':'http://vip.jlsprh.com/?url=',
    '618G1':'http://jx.618g.com/?url=',
    '618G2':'http://jx.618ge.com/?url=',
    '石头':'https://jiexi.071811.cc/jx.php?url=',
    '大亨':'http://jx.cesms.cn/?url=',
    '乐乐云':'https://660e.com/?url=',
    '无名':'https://www.administratorw.com/admin.php?url=',
    '163人':'http://api.jx.bugxx.com/cfee/vod.php?url=',
    '1717云':'https://www.1717yun.com/jx/ty.php?url=',
    '花园':'http://j.zz22x.com/jx/?url=',
    '免费接':'http://vip.jlsprh.com/index.php?url=',
    '那片':'http://api.nepian.com/ckparse/?url=',
    '酷绘':'http://appapi.svipv.kuuhui.com/plje/?id=',
    '百域阁(1)':'http://api.baiyug.cn/vip/index.php?url=',
    '百域阁(2)':'http://api.baiyug.vip/index.php?url=', 
    'vParse':'https://api.vparse.org/?url='
  }

  var JXMUSIC = [
    'http://www.socew.cn/',
    'http://mctool.cn/music/'
  ]

  var filterUrlList = [
    'ayxvip.com/622'
  ]

  function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)")
    var r = window.location.search.substr(1).match(reg)
    if(r!=null) return decodeURIComponent(r[2])
    return null
  }

  function isPhone () {
    var sUserAgent = navigator.userAgent.toLowerCase();
    var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
    var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
    var bIsMidp = sUserAgent.match(/midp/i) == "midp";
    var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
    var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
    var bIsAndroid = sUserAgent.match(/android/i) == "android";
    var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
    var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
    if(bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) return true
    return false
  }

  function clearTimer (timer) {
    clearInterval(timer)
    clearTimeout(timer)
    timer = null
  }
  
})