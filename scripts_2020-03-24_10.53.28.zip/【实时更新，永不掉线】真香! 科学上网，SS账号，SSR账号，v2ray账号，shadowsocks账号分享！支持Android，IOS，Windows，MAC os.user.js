// ==UserScript==
// @name    【实时更新，永不掉线】真香! 科学上网，SS账号，SSR账号，v2ray账号，shadowsocks账号分享！支持Android，IOS，Windows，MAC os
// @namespace    zkq
// @version      1.11.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       意外
// @include *zkq8.com/*
// @include http*://chaoshi.detail.tmall.com/*
// @include http*://detail.tmall.com/*
// @include http*://item.taobao.com/*
// @include http*://list.tmall.com/*
// @include http*://list.tmall.hk/*
// @include http*://www.taobao.com/*
// @include http*://www.tmall.com/*
// @include http*://s.taobao.com/*
// @include http*://detail.tmall.hk/*
// @include http*://chaoshi.tmall.com/*
// @grant        none
// @run-at       document-end
// ==/UserScript==
