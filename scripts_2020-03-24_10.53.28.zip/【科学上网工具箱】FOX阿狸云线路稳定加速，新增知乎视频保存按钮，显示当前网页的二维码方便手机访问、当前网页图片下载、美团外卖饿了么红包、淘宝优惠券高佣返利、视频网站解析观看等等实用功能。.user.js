// ==UserScript==
// @name              【科学上网工具箱】FOX阿狸云线路稳定加速，新增知乎视频保存按钮，显示当前网页的二维码方便手机访问、当前网页图片下载、美团外卖饿了么红包、淘宝优惠券高佣返利、视频网站解析观看等等实用功能。
// @namespace http://gongju.dadiyouhui03.cn/app/tool/youhou/index.html
// @version           1.2020021504
// @description      稳定独享线路，不仅是是居家必备替代谷歌助手的佳品。更是工作和学习的好帮手。低调使用支持Windows、Mac、Android、iOS
// @updateURL https://www.dadiyouhui02.cn/tampermonkey/gongju.user.js
// @match        *://*.baidu.com/*
// @match        *://*/*
// @require https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js
// @require https://cdn.bootcss.com/sweetalert/2.1.2/sweetalert.min.js
// @require https://cdn.bootcss.com/jquery.qrcode/1.0/jquery.qrcode.min.js
// @require https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js
// @require https://cdn.bootcss.com/html2canvas/0.5.0-beta4/html2canvas.js
// @require https://greasyfork.org/scripts/394700-greasyforktest/code/greasyforktest.js?version=777905
// @run-at            document-idle
// @grant             unsafeWindow
// @grant             GM_xmlhttpRequest
// @grant             GM_setClipboard
// @grant             GM_setValue
// @grant             GM_getValue
// @grant             GM_deleteValue
// @grant             GM_openInTab
// @grant             GM_registerMenuCommand
// @grant             GM_unregisterMenuCommand
// @grant             GM.getValue
// @grant             GM.setValue
// @grant             GM_info
// @grant             GM_notification
// @grant             GM_getResourceText
// @grant             GM_openInTab
// @grant             GM_download
// @noframes
// @connect     zhihu.com
// @connect     weixin.qq.com
// @connect     dadiyouhui02.cn

// @connect *
// ==/UserScript==
//修复部分BUG.
//声明：仅限于游戏加速，技术学习，外贸交流，请勿滥用。本插件的部分功能收集和转载的信息只为学习用，不参与客户端的开发和运营
//已知问题：如果安装有谷歌助手之类的插件和其他梯子的，可能会有冲突。那么请关闭他们，或者换个没有上述插件的浏览器方才可以正常使用。借用的第三方网站有很流行的淘宝优惠券返利功能类似的广告，不喜勿用。不影响插件使用

//新增显示网页二维码、网页图片下载、新增淘宝天猫和京东优惠券高佣返利功能、购物不花冤枉钱！最高可返70%视频网站视频解析观看、知乎视频网页添加下载按钮
//美团外卖红包、饿了么红包、滴滴红包、盒马红包、KFC瑞幸咖啡红包、
//
//短视频无水印解析下载，支持抖音、微视、小红书、微博、花椒等短视频、 BT磁力种子搜索、网易云酷狗等歌曲解析下载、淘宝京东优惠券等等实用功能。
//
//食用说明：先随便打开个网页，然后点开插件即可进入。进不了的可以按【alt + S】调出菜单
//
//看图。点开插件看到菜单！！进不了的可以按【ALT + A】调出菜单
//
//看图。点开插件可看到菜单！！进不了的可以按【ALT + A】调出菜单
//有人反映偶尔连接不上，若按教程设置好后如果不能连接请换个浏览器试试。
//超稳定线路，youtube 720P很快，google全程无压力。低调使用支持Windows、Mac、Android、iOS
//
//
//
//！！重要！！看图。先随便打开个网页。点开插件可看到菜单！！！！
//进入正题：这里包含全套工具和教程。支持Windows、Mac、Android、iOS
//
//1人1号专用， 每日重置2G流量，签到再送1G。每天都有3G流量，一般人已经足够使用。
//若需更多流量请自行充值，支持服务器运行！良心不易,公益更难，资源遵循付费优先原则
//
//禁止公开节点信息，如有发现一律删号


"use strict";

    GM_registerMenuCommand("【🌺  点击打开工具包】含：科学上网教程和工具", function(){
kexueshangwangddd.start();
    });

       GM_registerMenuCommand("【🌺  当前网页二维码】", function(){
    var ewm = '<div id="ewm" style="position:fixed;top:50%;left:50%;margin-left:-135px;margin-top:-135px;background-color:white;height:auto;padding:7px;">当前页面地址二维码<br>';

        		if ($('#ewm').length <= 0) {
            if (!document.querySelector('#showQRcodeJs')) {

                var div = document.createElement('div');
                div.setAttribute('id', 'showQRcodeJs');
                div.setAttribute('style', 'position:fixed;top:0;left:0;bottom:0;right:0;z-index:99999;background-color: rgba(0, 0, 0, 0.3);');
                div.innerHTML = ewm;
                document.body.appendChild(div);
                // 执行QRCode
                new QRCode(document.querySelector("#ewm"), window.location.href);
                 var sda = '<a  onclick=" document.getElementById(\'wxgzh\').style.display = \'none\';" id="wxgzh"  style="position: fixed;right: 18px;z-index: 9999;display:none;background: url(https://www.dadiyouhui02.cn/img/wxgz.jpg) no-repeat center center;background-size: 100% auto; background-color: #fff ; width: 200px;height: 350px;top:200px;"></a>'
                 if (window.frames.length != parent.frames.length) {
 sda = '';
}

                  var ata ="<style type=\"text/css\"> .nav{      padding-top: 1px; height:30px;          line-height:30px;          height:40px;          background:#ca3232;          border-radius:0 0 15px 15px;      } .nav ul{ list-style:none; } .nav li{            float:left;            width:20%;            text-align:center;   }   .nav a{ text-decoration:none; font-size: 14px;    height:40px;             color:#FFF;            font-family: -apple-system, BlinkMacSystemFont, 'San Francisco', 'Microsoft YaHei', 'PingFang SC','Hiragino Sans GB', 'WenQuanYi Micro Hei', 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell','Fira Sans', 'Droid Sans', 'Noto Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif,'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; }   .nav a:hover{             color:white;             background:#0e90d2;   }     </style> <div class=\"nav\">   <ul>               <li><a href=\"http://qw.dadiyouhui.cn/new.asp\">淘宝优惠券</a></li>       <li><a href=\"http://qw.dadiyouhui.cn/jd/new.htm\">京东优惠券</a></li>       <li><a href=\"http://qw.dadiyouhui.cn/fl.htm\">超级搜索</a></li>      <li><a href=\"http://qw.dadiyouhui.cn/shipin/kan.html\">视频解析</a></li>   <li><a href=\"http://a.dadiyouhui.cn/url/yyxz\">音乐下载</a></li>   </ul>   </div> ";
               sda=sda+" "+ata;
               $('#ewm').after(sda);
            } else {
                document.body.removeChild(document.querySelector('#showQRcodeJs'));
                colse.removeEventListener("click", colse, false);
            }

            var colse = document.querySelector('#showQRcodeJs');
            colse.addEventListener('click', colse = function() {
                document.body.removeChild(document.querySelector('#showQRcodeJs'));
            }, false);
        }
    });
            GM_registerMenuCommand("【🌺 下载当前网页图片】", function(){

  if ($('#plugin-super-gopicture-box').length > 0 ) {

$("#plugin-super-gopicture-box").remove();


	    }

            		var aasddtpstyle=function(){
	    	const style = document.createElement('style');
	    	style.innerHTML = `
	    		#plugin-super-gopicture-box{
	    			position: fixed;
				    top: 0;
				    right: 0;
				    bottom: 0;
				    left: 0;
				    overflow: hidden;
				    outline: 0;
				    -webkit-overflow-scrolling: touch;
				    background-color: rgb(0, 0, 0);
				    filter: alpha(opacity=60);
				    background-color: rgba(0, 0, 0, 0.6);
				    z-index: 9999999;
				    display:none;
	    		}
	    		#plugin-super-gopicture-box >.show-img{
					width:90%;
					max-width:1000px;
					height:calc(100% - 100px);
					max-height:1000px;
					margin:10px auto;
					background-color:#FFF;
					padding:0px 20px 0px 20px;
					position:relative;
				}
	    		#plugin-super-gopicture-box >.show-img img{
	    			max-width:100%;
	    		}
	    		#plugin-super-gopicture-box >.show-img >.img-header{
	    			height:35px;
	    			line-height:35px;
	    		}
	    		#plugin-super-gopicture-box >.show-img >.img-header>.title{
	    			font-size:16px;
	    		}
	    		#plugin-super-gopicture-box >.show-img>.img-header>.close-btn{
				    width: 18px!important;
				    height: 18px!important;
				    line-height: 18px!important;
				    text-align: center;
				    position: absolute;
				    top: 2px;
				    right: 2px;
				    cursor: pointer;
				    display: block;
				    color: #000;
				    background-color: #ccc;
				    font-size: 20px!important;
				}
	    		#plugin-super-gopicture-box >.show-img >.botton-operation{
	    			position: absolute;
				    height: 50px;
				    bottom: 0px;
				    right: 0px;
				    text-align: center;
				   	left: 50%;
   					transform: translate(-50%, 0px);
	    		}
	    		#plugin-super-gopicture-box >.show-img >.botton-operation>a{
	    			display:inline-block;
	    			padding:5px 10px;
	    			background-color:#ccc;
	    			border-radius:3px;
	    			margin-top:10px;
	    			font-size:14px;
	    			color:#000;
	    			text-decoration:none;
	    		}
	    		#plugin-super-gopicture-box >.show-img>.img-box{
	    			height:calc(100% - 70px);
	    			overflow-x: hidden;
	    			overflow-y: auto;
	    		}
	            #plugin-super-gopicture-box >.show-img>.img-box >.lst{
	            	display: block;
	            	list-style: none;
	            	margin: 0;padding: 0;
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li{
	            	display: inline-block;
	            	list-style: none;
	            	width: auto;
	            	height:auto;
	            	margin:0px 20px 20px 0px;
	            	background-color:#eee;
	            	overflow:hidden; cursor:
	            	pointer;position:relative;
	            	vertical-align:middle;
	            	border:3px solid rgba(255,255,255,0);
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst .imageItemResolution{
	            	position: absolute;
	            	left:0px;
	            	bottom:0px;
	            	background: #16fd0061;
	            	font-size:small;
	            	text-align: center;
	            	line-height: normal;
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li.selected-item,
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li.select-item:hover {
	            	-webkit-box-shadow: 6px 4px 8px 1px #f81fe0;
					-moz-box-shadow: 6px 4px 8px 1px #f81fe0;
					box-shadow: 6px 4px 8px 1px #f81fe0;
	            }
			`;
	    	document.head.append(style);
	    };
	    	var createpodal=function(){
	    	const divHtml = document.createElement('div');
	    	divHtml.innerHTML = `
				<div id="plugin-super-gopicture-box">
					<div class="show-img">
						<div class="img-header">
							<span class="title"><strong>图片列表 - <span id="plugin-total-pic-num"></span></strong></span>
							<span class="close-btn"><strong>×</strong></span>
						</div>
						<div class="img-box">
							<ul class='lst'></ul>
						</div>
						<div class="botton-operation">
							<a href="javascript:void(0);" id="plugin-op-reset-23ac">重置</a>
							<a href="javascript:void(0);" id="plugin-op-choiceall-23ac">全选</a>
							<a href="javascript:void(0);" id="plugin-op-download-23ac">下载</a>
						</div>
					</div>
				</div>
			`;
	    	document.body.append(divHtml);
	    };

	    var GetAllImg=function(){
            var h=[];
            var imgs=[];
            var allEl=$("body *");
            $.each(allEl,function(index,itemEl){
                var $el=$(itemEl);
                var el=$el[0];
                var elTagName=$el[0].tagName.toUpperCase();
                //img
                if(elTagName=="IMG"){
                    imgs.push($el.attr("src"));
                    return true;
                }
                //canvas
                if(elTagName=="CANVAS"){
                    imgs.push(el.toDataURL());
                    return true;
                }
                //INPUT图片形式
                if(elTagName=="INPUT"){
                	if($el.attr("type")=="image"){
                		imgs.push($el.attr("src"));
                    	return true;
                	}
                }
                //backgroundimage
                var backgroundImage = getComputedStyle(el).backgroundImage;
                if (backgroundImage !== 'none' && backgroundImage.startsWith('url')) {
                    imgs.push(backgroundImage.slice(5, -2));
                }
            });
            imgs=imgs.unique();
            $.each(imgs,function(index,item){
                var imgObj=HandleImg(item);
                var src=imgObj.imgSrc;
                var width=imgObj.width;
                var height=imgObj.height;
                var naturalWH=imgObj.naturalWidth+"x"+imgObj.naturalHeight;
                if(imgObj.naturalWidth<=15||imgObj.naturalHeight<=15) {return true;}
                var imgResolution='<span class="imageItemResolution" style="width:{0}px;">{1}</span>'.format(width,naturalWH);
                imgResolution=height>=32&&width>=32?imgResolution:"";
                var fe=GetFileExt(src);
                var fileExt=fe.type!=""?fe.ext+"("+fe.type+")":fe.ext;
                var LocalDownload=fe.type!=""?"Y":"N";
                var yellowBorder="";
                var isSelect="select-item";
                if(!imgObj.isCors){
                    yellowBorder="border:3px solid red";
                    //isSelect="";
                }
                var nameExt=fe.ext=="other"?"jpg":fe.ext;
                var fileName=(Math.round(new Date().getTime()/1000)+index)+"."+nameExt;
                var imgTitle="分辨率: {0} / 类型: {1}".format(naturalWH,fileExt);
                h.push('<li class="{8}" style="{7}" title="{6}" data-src="{0}" data-type="{9}" data-localdownload="{11}" data-filename="{10}">\
                            <img src="{0}" width="{1}px" height="{2}px">\
                            {5}</li>'
                        .format(src,width,height,width-6,height-6,imgResolution,imgTitle,yellowBorder,isSelect,fe.ext,fileName,LocalDownload));
            });
            $("span#plugin-total-pic-num").text(imgs.length+"张");
            return h.join("");
       	};
       	var GetFileExt=function(src){
            var fileExt={};
            var imgBase64Reg=/^\s*data:([a-z]+\/[a-z0-9-+.]+(;[a-z-]+=[a-z0-9-]+)?)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s]*?)\s*$/i;
            var imgExtReg=/(\.(\w+)\?)|(\.(\w+)$)/gim;
            if(imgBase64Reg.test(src)){
                var imgBase64ExtReg=/^\s*data:([a-z]+\/)([a-z0-9-+.]+)/gim;
                var s=imgBase64ExtReg.exec(src);
                fileExt.ext=s[2];
                fileExt.type="base64";
            }
            else if(imgExtReg.test(src)){
                fileExt.ext=src.match(imgExtReg)[0].replace(/\.|\?/gim,"");
                fileExt.type="";
            }
            else{
                fileExt.ext="other";
                fileExt.type="";
            }
            return fileExt;
        };
        var HandleImg=function(src){
            var outHeight=170;
            var imgObj={};
            var width,height,naturalWidth,naturalHeight,scaleWidth,scaleHeight,isCors;
            var image = new Image();
            image.src = src;
            width=parseInt(image.width);
            height=parseInt(image.height);
            naturalWidth=width;
            naturalHeight=height;
            outHeight=parseInt(outHeight);
            if(height<outHeight){
                scaleWidth=width;
                scaleHeight=height;
            }else{
                scaleWidth=parseInt(outHeight*width/height);
                scaleHeight=outHeight;
            }
            isCors=true;//corsEnabled(image.src);
            imgObj.imgSrc=image.src;
            imgObj.isCors=isCors;
            imgObj.naturalWidth=naturalWidth;
            imgObj.naturalHeight=naturalHeight;
            imgObj.width=scaleWidth;
            imgObj.height=scaleHeight;
            return imgObj;
        };
        var downloadImg=function (index,imgs){
            if(index>imgs.length-1) return;
            var delayTime=300;
            var src=imgs[index].src;
            var fileName=imgs[index].fileName;
            var localdownload=imgs[index].localdownload;
            if(localdownload=="Y"){
                GM_download(src,fileName);
                setTimeout(function(){
                    downloadImg(index + 1,imgs);
                }, delayTime);
            }
            else{
                GM_download({
                    url:src,
                    name:fileName,
                    onload:function(){
                        //downloadImg(index + 1,imgs);
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);
                    },
                    onerror:function(e){
                        console.error("第{0}几张图片{1}下载失败，失败原因：{2}".format(index+1,fileName,e.error));
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);

                    },
                    ontimeout: function(){
			    		console.error("第{0}几张图片{1}下载超时".format(index+1,fileName));
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);
			    	}
                });
            }
        };
        var tpallll=function(){
        	var h = GetAllImg();
        	$("div#plugin-super-gopicture-box ul.lst").empty();
			$("div#plugin-super-gopicture-box ul.lst").html(h+"<li class='clearFloat'></li>");
			$("div#plugin-super-gopicture-box").show();

			$("body").on("click","div#plugin-super-gopicture-box span.close-btn",function(){
				$("div#plugin-super-gopicture-box").hide();
			});


			$("body").on("click","div#plugin-super-gopicture-box .select-item",function(){

				if($(this).hasClass("selected-item")){
					$(this).removeClass("selected-item");
				}else{
					$(this).addClass("selected-item");
				}
			})
			//重置选择
			$("body").on("click", "#plugin-op-reset-23ac", function(){
				$("div#plugin-super-gopicture-box").find(".select-item").each(function(){
					$(this).removeClass("selected-item");
				});
			});
			//选择全部
			$("body").on("click", "#plugin-op-choiceall-23ac", function(){
				$("div#plugin-super-gopicture-box").find(".select-item").each(function(){
					$(this).addClass("selected-item");
				});
			});
			//下载所选择的图片
			$("body").on("click", "#plugin-op-download-23ac", function(){
				var imgs=[];
				$("div#plugin-super-gopicture-box").find(".selected-item").each(function(index,imgItem){
                    var $imgItem=$(this);
                    var imgSrc=$imgItem.attr("data-src");
                    var localdownload=$imgItem.attr("data-localdownload");
                    var imgFileName=$imgItem.attr("data-filename");
                    imgs.push({
                        src:imgSrc,
                        fileName:imgFileName,
                        localdownload:localdownload
                    });
                });
                downloadImg(0,imgs);
			});
        };

   	if (typeof Array.prototype['unique'] == 'undefined') {
        Array.prototype.unique = function() {
            var temparr=[];
            $.each(this,function(i,v){
                if($.inArray(v,temparr)==-1) {
                    temparr.push(v);
                }
            });
            return temparr;
        }
    }
   	if(typeof String.prototype['format'] == 'undefined') {
    	String.prototype.format = function () {
		    var i = arguments;
	        return this.replace(/\{(\d+)\}/g,
	        function(t, o) {
	            return i[o]
	        })
		};
    }


            	    if (window.top == window.self){
       if ($('#plugin-super-gopicture-box').length <= 0 ) {

    //脚本只运行在顶层窗口


    	aasddtpstyle();
	    	createpodal();
	 tpallll()

	    }
	    }


    });





var kexueshangwangddd={};
    kexueshangwangddd.start=function(){
       	    if (window.top == window.self){

	if($("#zkdgjxmainiframe").length>0){

			if(  $('#zkdgjxmainiframe').css("display")=='none' ) {  	$('#zkdgjxmainiframe').css('display','block');
 }else{
$('#zkdgjxmainiframe').css("display","none");
}
	}else{
$('head').after('<div style="position: fixed;top: 0;margin-bottom: 5px;width:100%;z-index:999999999;" id="zkdgjxmainiframe" ><div style="width:100%;background-color: #9400D3;text-align:center;color:#FFF;font-size:22px;font-weight:bold" id="gbzkdgjx" onclick = "document.getElementById(\'zkdgjxmainiframe\').style.display=\'none\';" >     --> 工具箱正在加载中 ..... 请稍后.... <--      </div><div style="background-color: #FFF;">     <iframe id="zkdmainiframe" width="100%" height='+($(window).height()-40) +' src="https://www.dadiyouhui02.cn/app/tool/tool.html?p='+Math.ceil(Math.random()*9999999999999)+'"   frameborder="0" scrolling="auto"></iframe> </div> </div>');
}
}
	if($("#zkdgjxmainiframe").length>0){
	  setTimeout(function(){
$("#gbzkdgjx").text("-->  快捷键：ALT+A 打开/关闭本工具，ALT+X：下载当前网页图片，ALT+C：生成当前网页地址的二维码，方便手机访问 ██ 科学工具箱：► 点此关闭 ◄");
                        }, 2000);

	}
    };





     if (window.location.href.search("ie=UTF-8&wd=5201314")>=0){
kexueshangwangddd.start();

}





(function() {


var colse = '';


var kexueshangdwangddd={};
    kexueshangdwangddd.start=function(){
       	    if (window.top == window.self){

	if($("#zkdgjxmainiframe").length>0){

		if(  $('#zkdgjxmainiframe').css("display")=='none' ) {  	$('#zkdgjxmainiframe').css('display','block');
 }else{
$('#zkdgjxmainiframe').css("display","none");
}

	}else{
$('head').after('<div style="position: fixed;top: 0;margin-bottom: 5px;width:100%;z-index:999999999;" id="zkdgjxmainiframe" ><div style="width:100%;background-color: #9400D3;text-align:center;color:#FFF;font-size:22px;font-weight:bold" id="gbzkdgjx" onclick = "document.getElementById(\'zkdgjxmainiframe\').style.display=\'none\';" >     --> 工具箱正在加载中 ..... 请稍后.... <--      </div><div style="background-color: #FFF;">     <iframe id="zkdmainiframe" width="100%" height='+($(window).height()-40) +' src="https://www.dadiyouhui02.cn/app/tool/tool.html?p='+Math.ceil(Math.random()*9999999999999)+'"  frameborder="0" scrolling="auto"></iframe> </div> </div>');
}
}
	if($("#zkdgjxmainiframe").length>0){
	  setTimeout(function(){
$("#gbzkdgjx").text("-->  快捷键：ALT+A 打开/关闭本工具，ALT+X：下载当前网页图片，ALT+C：生成当前网页地址的二维码，方便手机访问 ██ 科学工具箱：► 点此关闭 ◄");
                        }, 2000);

	}
    };

    document.onkeydown = function(e) {
    	 var $ = $ || window.$;

    var ewm = '<div id="ewm" style="position:fixed;top:50%;left:50%;margin-left:-135px;margin-top:-135px;background-color:white;height:auto;padding:7px;">当前页面地址二维码<br>';
      if (e.keyCode == 90 && e.altKey ) {
   if (window.top == window.self){
   kexueshangdwangddd.start();
    }
       }
          if (e.keyCode == 65 && e.altKey) {
   if (window.top == window.self){
   kexueshangdwangddd.start();
    }
       }

        if (e.keyCode == 67 && e.altKey) {

        		if ($('#ewm').length <= 0) {
            if (!document.querySelector('#showQRcodeJs')) {

                var div = document.createElement('div');
                div.setAttribute('id', 'showQRcodeJs');
                div.setAttribute('style', 'position:fixed;top:0;left:0;bottom:0;right:0;z-index:99999;background-color: rgba(0, 0, 0, 0.3);');
                div.innerHTML = ewm;
                document.body.appendChild(div);
                // 执行QRCode
                new QRCode(document.querySelector("#ewm"), window.location.href);
                 var sda = '<a  onclick=" document.getElementById(\'wxgzh\').style.display = \'none\';" id="wxgzh"  style="position: fixed;right: 18px;z-index: 9999;display:none;background: url(https://www.dadiyouhui02.cn/img/gzh.jpg) no-repeat center center;background-size: 100% auto; background-color: #fff ; width: 200px;height: 350px;top:200px;"></a>'
                 if (window.frames.length != parent.frames.length) {
 sda = '';
}

                  var ata ="<style type=\"text/css\"> .nav{      padding-top: 1px; height:30px;          line-height:30px;          height:40px;          background:#ca3232;          border-radius:0 0 15px 15px;      } .nav ul{ list-style:none; } .nav li{            float:left;            width:20%;            text-align:center;   }   .nav a{ text-decoration:none; font-size: 14px;    height:40px;             color:#FFF;            font-family: -apple-system, BlinkMacSystemFont, 'San Francisco', 'Microsoft YaHei', 'PingFang SC','Hiragino Sans GB', 'WenQuanYi Micro Hei', 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell','Fira Sans', 'Droid Sans', 'Noto Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif,'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'; }   .nav a:hover{             color:white;             background:#0e90d2;   }     </style> <div class=\"nav\">   <ul>               <li><a href=\"http://qw.dadiyouhui.cn/new.asp\">淘宝优惠券</a></li>       <li><a href=\"http://qw.dadiyouhui.cn/jd/new.htm\">京东优惠券</a></li>       <li><a href=\"http://qw.dadiyouhui.cn/fl.htm\">超级搜索</a></li>      <li><a href=\"http://qw.dadiyouhui.cn/shipin/kan.html\">视频解析</a></li>   <li><a href=\"http://a.dadiyouhui.cn/url/yyxz\">音乐下载</a></li>   </ul>   </div> ";
               sda=sda+" "+ata;
               $('#ewm').after(sda);
            } else {
                document.body.removeChild(document.querySelector('#showQRcodeJs'));
                colse.removeEventListener("click", colse, false);
            }

            var colse = document.querySelector('#showQRcodeJs');
            colse.addEventListener('click', colse = function() {
                document.body.removeChild(document.querySelector('#showQRcodeJs'));
            }, false);
        }
        }

        if(window.location.href.search("taobao.com")<= 0 || window.location.href.search("tmall.com") <= 0) {
            if (e.keyCode == 88 && e.altKey) {


            	 	   if ($('#plugin-super-gopicture-box').length > 0 ) {

$("#plugin-super-gopicture-box").remove();


	    }

            		var aasddtpstyle=function(){
	    	const style = document.createElement('style');
	    	style.innerHTML = `
	    		#plugin-super-gopicture-box{
	    			position: fixed;
				    top: 0;
				    right: 0;
				    bottom: 0;
				    left: 0;
				    overflow: hidden;
				    outline: 0;
				    -webkit-overflow-scrolling: touch;
				    background-color: rgb(0, 0, 0);
				    filter: alpha(opacity=60);
				    background-color: rgba(0, 0, 0, 0.6);
				    z-index: 9999999;
				    display:none;
	    		}
	    		#plugin-super-gopicture-box >.show-img{
					width:90%;
					max-width:1000px;
					height:calc(100% - 100px);
					max-height:1000px;
					margin:10px auto;
					background-color:#FFF;
					padding:0px 20px 0px 20px;
					position:relative;
				}
	    		#plugin-super-gopicture-box >.show-img img{
	    			max-width:100%;
	    		}
	    		#plugin-super-gopicture-box >.show-img >.img-header{
	    			height:35px;
	    			line-height:35px;
	    		}
	    		#plugin-super-gopicture-box >.show-img >.img-header>.title{
	    			font-size:16px;
	    		}
	    		#plugin-super-gopicture-box >.show-img>.img-header>.close-btn{
				    width: 18px!important;
				    height: 18px!important;
				    line-height: 18px!important;
				    text-align: center;
				    position: absolute;
				    top: 2px;
				    right: 2px;
				    cursor: pointer;
				    display: block;
				    color: #000;
				    background-color: #ccc;
				    font-size: 20px!important;
				}
	    		#plugin-super-gopicture-box >.show-img >.botton-operation{
	    			position: absolute;
				    height: 50px;
				    bottom: 0px;
				    right: 0px;
				    text-align: center;
				   	left: 50%;
   					transform: translate(-50%, 0px);
	    		}
	    		#plugin-super-gopicture-box >.show-img >.botton-operation>a{
	    			display:inline-block;
	    			padding:5px 10px;
	    			background-color:#ccc;
	    			border-radius:3px;
	    			margin-top:10px;
	    			font-size:14px;
	    			color:#000;
	    			text-decoration:none;
	    		}
	    		#plugin-super-gopicture-box >.show-img>.img-box{
	    			height:calc(100% - 70px);
	    			overflow-x: hidden;
	    			overflow-y: auto;
	    		}
	            #plugin-super-gopicture-box >.show-img>.img-box >.lst{
	            	display: block;
	            	list-style: none;
	            	margin: 0;padding: 0;
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li{
	            	display: inline-block;
	            	list-style: none;
	            	width: auto;
	            	height:auto;
	            	margin:0px 20px 20px 0px;
	            	background-color:#eee;
	            	overflow:hidden; cursor:
	            	pointer;position:relative;
	            	vertical-align:middle;
	            	border:3px solid rgba(255,255,255,0);
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst .imageItemResolution{
	            	position: absolute;
	            	left:0px;
	            	bottom:0px;
	            	background: #16fd0061;
	            	font-size:small;
	            	text-align: center;
	            	line-height: normal;
	            }
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li.selected-item,
	            #plugin-super-gopicture-box >.show-img>.img-box > .lst li.select-item:hover {
	            	-webkit-box-shadow: 6px 4px 8px 1px #f81fe0;
					-moz-box-shadow: 6px 4px 8px 1px #f81fe0;
					box-shadow: 6px 4px 8px 1px #f81fe0;
	            }
			`;
	    	document.head.append(style);
	    };
	    	var createpodal=function(){
	    	const divHtml = document.createElement('div');
	    	divHtml.innerHTML = `
				<div id="plugin-super-gopicture-box">
					<div class="show-img">
						<div class="img-header">
							<span class="title"><strong>图片列表 - <span id="plugin-total-pic-num"></span></strong></span>
							<span class="close-btn"><strong>×</strong></span>
						</div>
						<div class="img-box">
							<ul class='lst'></ul>
						</div>
						<div class="botton-operation">
							<a href="javascript:void(0);" id="plugin-op-reset-23ac">重置</a>
							<a href="javascript:void(0);" id="plugin-op-choiceall-23ac">全选</a>
							<a href="javascript:void(0);" id="plugin-op-download-23ac">下载</a>
						</div>
					</div>
				</div>
			`;
	    	document.body.append(divHtml);
	    };

	    var GetAllImg=function(){
            var h=[];
            var imgs=[];
            var allEl=$("body *");
            $.each(allEl,function(index,itemEl){
                var $el=$(itemEl);
                var el=$el[0];
                var elTagName=$el[0].tagName.toUpperCase();
                //img
                if(elTagName=="IMG"){
                    imgs.push($el.attr("src"));
                    return true;
                }
                //canvas
                if(elTagName=="CANVAS"){
                    imgs.push(el.toDataURL());
                    return true;
                }
                //INPUT图片形式
                if(elTagName=="INPUT"){
                	if($el.attr("type")=="image"){
                		imgs.push($el.attr("src"));
                    	return true;
                	}
                }
                //backgroundimage
                var backgroundImage = getComputedStyle(el).backgroundImage;
                if (backgroundImage !== 'none' && backgroundImage.startsWith('url')) {
                    imgs.push(backgroundImage.slice(5, -2));
                }
            });
            imgs=imgs.unique();
            $.each(imgs,function(index,item){
                var imgObj=HandleImg(item);
                var src=imgObj.imgSrc;
                var width=imgObj.width;
                var height=imgObj.height;
                var naturalWH=imgObj.naturalWidth+"x"+imgObj.naturalHeight;
                if(imgObj.naturalWidth<=15||imgObj.naturalHeight<=15) {return true;}
                var imgResolution='<span class="imageItemResolution" style="width:{0}px;">{1}</span>'.format(width,naturalWH);
                imgResolution=height>=32&&width>=32?imgResolution:"";
                var fe=GetFileExt(src);
                var fileExt=fe.type!=""?fe.ext+"("+fe.type+")":fe.ext;
                var LocalDownload=fe.type!=""?"Y":"N";
                var yellowBorder="";
                var isSelect="select-item";
                if(!imgObj.isCors){
                    yellowBorder="border:3px solid red";
                    //isSelect="";
                }
                var nameExt=fe.ext=="other"?"jpg":fe.ext;
                var fileName=(Math.round(new Date().getTime()/1000)+index)+"."+nameExt;
                var imgTitle="分辨率: {0} / 类型: {1}".format(naturalWH,fileExt);
                h.push('<li class="{8}" style="{7}" title="{6}" data-src="{0}" data-type="{9}" data-localdownload="{11}" data-filename="{10}">\
                            <img src="{0}" width="{1}px" height="{2}px">\
                            {5}</li>'
                        .format(src,width,height,width-6,height-6,imgResolution,imgTitle,yellowBorder,isSelect,fe.ext,fileName,LocalDownload));
            });
            $("span#plugin-total-pic-num").text(imgs.length+"张");
            return h.join("");
       	};
       	var GetFileExt=function(src){
            var fileExt={};
            var imgBase64Reg=/^\s*data:([a-z]+\/[a-z0-9-+.]+(;[a-z-]+=[a-z0-9-]+)?)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s]*?)\s*$/i;
            var imgExtReg=/(\.(\w+)\?)|(\.(\w+)$)/gim;
            if(imgBase64Reg.test(src)){
                var imgBase64ExtReg=/^\s*data:([a-z]+\/)([a-z0-9-+.]+)/gim;
                var s=imgBase64ExtReg.exec(src);
                fileExt.ext=s[2];
                fileExt.type="base64";
            }
            else if(imgExtReg.test(src)){
                fileExt.ext=src.match(imgExtReg)[0].replace(/\.|\?/gim,"");
                fileExt.type="";
            }
            else{
                fileExt.ext="other";
                fileExt.type="";
            }
            return fileExt;
        };
        var HandleImg=function(src){
            var outHeight=170;
            var imgObj={};
            var width,height,naturalWidth,naturalHeight,scaleWidth,scaleHeight,isCors;
            var image = new Image();
            image.src = src;
            width=parseInt(image.width);
            height=parseInt(image.height);
            naturalWidth=width;
            naturalHeight=height;
            outHeight=parseInt(outHeight);
            if(height<outHeight){
                scaleWidth=width;
                scaleHeight=height;
            }else{
                scaleWidth=parseInt(outHeight*width/height);
                scaleHeight=outHeight;
            }
            isCors=true;//corsEnabled(image.src);
            imgObj.imgSrc=image.src;
            imgObj.isCors=isCors;
            imgObj.naturalWidth=naturalWidth;
            imgObj.naturalHeight=naturalHeight;
            imgObj.width=scaleWidth;
            imgObj.height=scaleHeight;
            return imgObj;
        };
        var downloadImg=function (index,imgs){
            if(index>imgs.length-1) return;
            var delayTime=300;
            var src=imgs[index].src;
            var fileName=imgs[index].fileName;
            var localdownload=imgs[index].localdownload;
            if(localdownload=="Y"){
                GM_download(src,fileName);
                setTimeout(function(){
                    downloadImg(index + 1,imgs);
                }, delayTime);
            }
            else{
                GM_download({
                    url:src,
                    name:fileName,
                    onload:function(){
                        //downloadImg(index + 1,imgs);
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);
                    },
                    onerror:function(e){
                        console.error("第{0}几张图片{1}下载失败，失败原因：{2}".format(index+1,fileName,e.error));
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);

                    },
                    ontimeout: function(){
			    		console.error("第{0}几张图片{1}下载超时".format(index+1,fileName));
                        setTimeout(function(){
                            downloadImg(index + 1,imgs);
                        }, delayTime);
			    	}
                });
            }
        };
        var tpallll=function(){
        	var h = GetAllImg();
        	$("div#plugin-super-gopicture-box ul.lst").empty();
			$("div#plugin-super-gopicture-box ul.lst").html(h+"<li class='clearFloat'></li>");
			$("div#plugin-super-gopicture-box").show();

			$("body").on("click","div#plugin-super-gopicture-box span.close-btn",function(){
				$("div#plugin-super-gopicture-box").hide();
			});


			$("body").on("click","div#plugin-super-gopicture-box .select-item",function(){

				if($(this).hasClass("selected-item")){
					$(this).removeClass("selected-item");
				}else{
					$(this).addClass("selected-item");
				}
			})
			//重置选择
			$("body").on("click", "#plugin-op-reset-23ac", function(){
				$("div#plugin-super-gopicture-box").find(".select-item").each(function(){
					$(this).removeClass("selected-item");
				});
			});
			//选择全部
			$("body").on("click", "#plugin-op-choiceall-23ac", function(){
				$("div#plugin-super-gopicture-box").find(".select-item").each(function(){
					$(this).addClass("selected-item");
				});
			});
			//下载所选择的图片
			$("body").on("click", "#plugin-op-download-23ac", function(){
				var imgs=[];
				$("div#plugin-super-gopicture-box").find(".selected-item").each(function(index,imgItem){
                    var $imgItem=$(this);
                    var imgSrc=$imgItem.attr("data-src");
                    var localdownload=$imgItem.attr("data-localdownload");
                    var imgFileName=$imgItem.attr("data-filename");
                    imgs.push({
                        src:imgSrc,
                        fileName:imgFileName,
                        localdownload:localdownload
                    });
                });
                downloadImg(0,imgs);
			});
        };

   	if (typeof Array.prototype['unique'] == 'undefined') {
        Array.prototype.unique = function() {
            var temparr=[];
            $.each(this,function(i,v){
                if($.inArray(v,temparr)==-1) {
                    temparr.push(v);
                }
            });
            return temparr;
        }
    }
   	if(typeof String.prototype['format'] == 'undefined') {
    	String.prototype.format = function () {
		    var i = arguments;
	        return this.replace(/\{(\d+)\}/g,
	        function(t, o) {
	            return i[o]
	        })
		};
    }


            	    if (window.top == window.self){
       if ($('#plugin-super-gopicture-box').length <= 0 ) {

    //脚本只运行在顶层窗口


    	aasddtpstyle();
	    	createpodal();
	 tpallll()

	    }
	    }
	    }
	    }
    };


})();

