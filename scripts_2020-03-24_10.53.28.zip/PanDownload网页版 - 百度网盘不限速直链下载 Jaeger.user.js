// ==UserScript==
// @name         PanDownload网页版 - 百度网盘不限速直链下载 Jaeger
// @namespace    https://github.com/jae-jae
// @version      1.3
// @description  百度网盘分享链接自动跳转到 PanDownload 网页版去下载
// @author       Jaeger
// @match        https://pan.baidu.com/s/*
// @match        https://pan.baidu.com/share/*
// @match        https://yun.baidu.com/s/*
// @grant        GM_openInTab
// ==/UserScript==

(function() {
    'use strict';

    let link = location.href;
    link = link.replace('baidu.com','baiduwp.com');
    GM_openInTab(link, { active: true });
})();
